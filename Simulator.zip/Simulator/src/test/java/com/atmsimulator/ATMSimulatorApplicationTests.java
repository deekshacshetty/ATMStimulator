package com.atmsimulator;

import static org.junit.Assert.assertEquals;

import java.util.HashMap;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.junit4.SpringRunner;

import com.atmsimulator.utility.DenominationUtility;
import com.atmsimulator.utility.Utility;


@ComponentScan({ "com.atmsimulator.utility" })
@RunWith(SpringRunner.class)
@SpringBootTest
public class ATMSimulatorApplicationTests
{
    @Autowired
    Utility utility;
    
    @Autowired
    DenominationUtility denoUtility;
    
    @Test
    public void testgetTotalForDenominations()
    {
         int total = utility.getTotalForDenominations("50,50");
        assertEquals(100, total);
    }
    
    
    @Test
    public void testgetTotalForDenominations2()
    {
         int total = utility.getTotalForDenominations("50");
        assertEquals(50, total);
    }

    @Test
    public void testIsEmpty() {
        boolean bEmpty = utility.isEmptyOrNull(null);
        assertEquals(true, bEmpty);
        
    }
    
    @Test
    public void testIsEmpty2() {
        boolean bEmpty = utility.isEmptyOrNull("");
        assertEquals(true, bEmpty);
        
    }
    
    @Test
    public void testIsEmpty3() {
        boolean bEmpty = utility.isEmptyOrNull("not");
        assertEquals(false, bEmpty);
        
    }
    
    
    @Test
    public void testValidDenomination() {
        boolean bValid = utility.isValidInput("50,30");
        assertEquals(true, bValid);
        
    }
    
    @Test
    public void testInValidDenomination2() {
        boolean bValid = utility.isValidInput("50,sc");
        assertEquals(false, bValid);
        
    }
    
    @Test
    public void testValidAmount() {
        boolean bValid = utility.isValidNumber("100");
        assertEquals(true, bValid);
        
    }
    
    
    @Test
    public void testInValidAmount() {
        boolean bValid = utility.isValidNumber("scd");
        assertEquals(false, bValid);
        
    }
    
    @Test
    public void testgetDenominations() {
        HashMap hmDenomination = denoUtility.getDenominations(50);
        
        boolean bTrue = hmDenomination.size()==1;
        assertEquals(true, bTrue);
        
    }
    
    
 
}
