package com.atmsimulator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.atmsimulator.utility.PropertiesHandler;

@SpringBootApplication
@ComponentScan({"com.atmsimulator.controller"})
@EnableConfigurationProperties(PropertiesHandler.class)
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
public class ATMSimulatorApplication
{

    @RequestMapping("/")
    String home()
    {
        return "Welcome to atm simulator";
    }
    
    

    @RequestMapping(value = "/depositAmt/{amount}", method = RequestMethod.GET)
    String convert(@PathVariable String amount )
    {
        return amount;
    }

    public static void main(String[] args)
    {
        SpringApplication.run(ATMSimulatorApplication.class, args);
    }

}
