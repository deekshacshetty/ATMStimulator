package com.atmsimulator.utility;

import java.util.HashMap;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Utility {
    
    @Autowired
    PropertiesHandler propertiesHandler;
    
    /**
     * method to add all the denominations ang give the total
     * @param strDenominations
     * @return
     */
    public int getTotalForDenominations(String strDenominations) {
        StringTokenizer strToken = new StringTokenizer(strDenominations);

        int total = 0;
        HashMap deno = (HashMap) propertiesHandler.getDeno();
        while (strToken.hasMoreTokens()) {
            int amt = Integer.parseInt(strToken.nextToken(","));
            total = total + amt;
            
            // ensure the property is updated

            String key = "" + amt;
           
            int current_count = Integer.parseInt((String) deno.get(key));
            String incrCount = "" + ++current_count;
            deno.put(key, incrCount);
        }
        propertiesHandler.setDeno(deno);
        return total;
    }
    
    
    /**
     * Method to check if string is null or empty
     * @param value
     * @return boolean
     */
    public boolean isEmptyOrNull(String value) {
        boolean ret = false;

        if (null == value || value.isEmpty()) {
            ret = true;
        }

        return ret;
    }

    
    /**
     * method to check of the denominations are enters correctly
     * @param inputDeno
     * @return
     */
    public boolean isValidInput(String inputDeno) {
        String regEx = "[0-9]+(,[0-9]+)*";

        return Pattern.matches(regEx, inputDeno);
    }
    
    /**
     * method to check if the input is a valid number
     * @param inputDeno
     * @return
     */
    public boolean isValidNumber(String inputDeno) {
        String regEx= "\"^\\\\d+$\"";
        Pattern r = Pattern.compile(regEx);
        return inputDeno.matches("^\\d+$");
     }

}
