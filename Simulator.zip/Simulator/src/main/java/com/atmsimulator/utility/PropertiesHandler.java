package com.atmsimulator.utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:extention.properties")
@ConfigurationProperties(prefix = "")
public class PropertiesHandler
{

    public void setDeno(Map<String, String> deno) {
        this.deno = deno;
    }




    private Map<String, String> properties = new HashMap<>();

    private int[]  denominations ;
    private Map<String, String> deno = new HashMap<>();
    
 

    
    
    public Map<String, String> getDeno() {
        return deno;
    }

    @PostConstruct
    private void loadProperty()
    {
        int count=0;
        deno.entrySet().stream().forEach(stringStringEntry -> {
            String conversionName = stringStringEntry.getKey().toUpperCase();
            
            
            String conversionValue = stringStringEntry.getValue();
            properties.put(conversionName, conversionValue); 
        });
       
        denominations= new int[deno.size()];
        for (Entry<String, String> entry : deno.entrySet()) {
            int denomin = Integer.parseInt(entry.getKey());
            denominations[count]=denomin;
             count++;
        }
            
            
         
    }

    public int[] getDenominations() {
    
        return denominations;
    }




    /**
     * Return the value of the specified application property
     *
     * @param propertyKey - Application property name
     * @return String - Value of the property
     */
    public String getProperty(String propertyKey)
    {
        return String.valueOf(properties.get(propertyKey));
    }

}
