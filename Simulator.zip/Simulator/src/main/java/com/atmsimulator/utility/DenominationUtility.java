package com.atmsimulator.utility;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

 
@Component
public class DenominationUtility {
    
    @Autowired
    PropertiesHandler propertiesHandler;
     
    public  HashMap getDenominations(int toAmt) {
        HashMap hmDeno = new HashMap();
        int[] denominations = propertiesHandler.getDenominations();
        Map<String,String> denoCount = propertiesHandler.getDeno();

        for (int i = 0; i < denominations.length; i++) {
            int noOfNotes = 0;
            int denomination =denominations[i];
            String key=""+denomination;
            int repoNotes = Integer.parseInt(denoCount.get(key));
            if (toAmt >= denominations[i]) {
                noOfNotes = toAmt / denominations[i];
                if(repoNotes < noOfNotes) {
                    noOfNotes=repoNotes;
                }
                
                toAmt = toAmt - (noOfNotes * denominations[i]);
            }

            hmDeno.put(denominations[i], noOfNotes);
            if (toAmt == 0) {
                break;
            }
        }
        
        
        /**
         * If ATM cannot dispense cash
         */
        if(toAmt!= 0) {
            return null;
        }
            

        return hmDeno;

    }
     
     

}
