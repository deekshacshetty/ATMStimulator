package com.atmsimulator;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


public class Transaction {
    

    private String time;
    private String type;
    private int amount;
    private int closingBalance;
    public String getTime() {
        return time;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public String getType() {
        return type;
    }
    public void setType(String type) {
        this.type = type;
    }
    public int getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
    public int getClosingBalance() {
        return closingBalance;
    }
    public void setClosingBalance(int closingBalance) {
        this.closingBalance = closingBalance;
    } 
}
