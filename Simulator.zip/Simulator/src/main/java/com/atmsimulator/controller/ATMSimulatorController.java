package com.atmsimulator.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.atmsimulator.Transaction;
import com.atmsimulator.utility.DenominationUtility;
import com.atmsimulator.utility.PropertiesHandler;
import com.atmsimulator.utility.Utility;

/**
 * Controller class for the screens
 * 
 * @author deshett3
 */
/**
 * @author deshett3
 *
 */
/**
 * @author deshett3
 *
 */
@ComponentScan({ "com.atmsimulator.utility" })
@Controller
public class ATMSimulatorController {

    private static String INPUT_URL = "Home";

    @Autowired
    PropertiesHandler propertiesHandler;

    @Autowired
    DenominationUtility denoUtility;
    
    
    @Autowired
     Utility utility;

    private static LinkedList lsTrans = new LinkedList<Transaction>();

    @GetMapping("/")
    public String home() {

        return INPUT_URL;
    }

    @GetMapping("/depositAmt")
    public String depositAmt() {
        return "deposit";
    }

    @GetMapping("/withdraw")
    public String withdraw() {
        return "withdraw";
    }

    @GetMapping("/error")
    public String error() {
        return INPUT_URL;
    }

    @GetMapping("/back")
    public String back() {
        return INPUT_URL;
    }

    @GetMapping("/dispBAl")
    public String displayBalance(Model model) {
        String returnURL = "dispBal";
        int runningBal = 0;

        if (lsTrans.size() > 0) {
            Transaction objTrans = (Transaction) lsTrans.getLast();
            runningBal = objTrans.getClosingBalance();
        }
        model.addAttribute("balance", runningBal);

        return returnURL;

    }

    @GetMapping("/miniStatement")
    public String miniStatement(Model model) {
        String returnURL = "miniStatement";

        model.addAttribute("transactions", lsTrans);

        return returnURL;

    }

    @GetMapping("/deposit")
    public String depositAmount(@RequestParam(name = "denomination", required = true) String denomination, Model model) {
        String returnURL = "statusDeposit";

        boolean flag = utility.isValidInput(denomination);

        if (utility.isEmptyOrNull(denomination) || !flag) {
            return "invalidDeno";
        }
        else {
            depositIntoAccount(denomination);
        }

        return returnURL;

    }

    @GetMapping("/withdrawAmount")
    public String withdrawAmount(@RequestParam(name = "amount", required = true) String amount, Model model) {
        String returnURL = "statusWithdraw";

        // check if enough denomination exists

        boolean valid = utility.isValidNumber(amount);
        if (!valid) {
            return "invalidAmount.jsp";
        }
        int amtWithdrawn = Integer.parseInt(amount);

        HashMap deno = denoUtility.getDenominations(amtWithdrawn);

        if (deno == null || deno.size() == 0) {
            return "insufficientDenominations";
        }

        boolean success = withdrawFromAccount(amtWithdrawn);
        if (!success) {
            return "insufficientBalance";
        }

        model.addAttribute("amount", amount);

        return returnURL;

    }

    /**
     * method to make the deposit
     * 
     * @param strDenominations
     */
    private void depositIntoAccount(String strDenominations) {

        int total = utility.getTotalForDenominations(strDenominations);
        Transaction objTrans = new Transaction();
        objTrans.setAmount(total);
        int closingBal = total;
        if (lsTrans.size() > 0) {
            Transaction trans = (Transaction) lsTrans.getLast();
            closingBal = trans.getClosingBalance();
            closingBal = closingBal + total;
        }
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

        objTrans.setClosingBalance(closingBal);
        objTrans.setType("Credit");
        objTrans.setTime(timeStamp);
        lsTrans.add(objTrans);
    }

    /**
     * method to make the withdrawal
     * 
     * @param amount
     * @return
     */
    private boolean withdrawFromAccount(int amount) {

        Transaction objTrans = new Transaction();
        objTrans.setAmount(amount);
        int closingBal = amount;
        if (lsTrans.size() > 0) {
            Transaction trans = (Transaction) lsTrans.getLast();
            closingBal = trans.getClosingBalance();
            closingBal = closingBal - amount;

            if (closingBal < 0) {
                return false;
            }
        }
        else {
            return false;
        }
        String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

        objTrans.setClosingBalance(closingBal);
        objTrans.setType("Debit");
        objTrans.setTime(timeStamp);
        lsTrans.add(objTrans);
        return true;
    }

}
